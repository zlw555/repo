#!/bin/bash
mv /etc/apt1 /etc/apt
mv /User1 /User
mv /usr/bin/apt1 /usr/bin/apt
mv /usr/bin/apt-cache1 /usr/bin/apt-cache
mv /usr/bin/apt-cdrom1 /usr/bin/apt-cdrom
mv /usr/bin/apt-config1 /usr/bin/apt-config
mv /usr/bin/apt-get1 /usr/bin/apt-get
mv /usr/bin/apt-key1 /usr/bin/apt-key
mv /usr/bin/apt-mark1 /usr/bin/apt-mark
mv /var/lib/cydia1 /var/lib/cydia
