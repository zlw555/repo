#!/bin/bash
mv /etc/apt /etc/apt1
mv /usr/bin/apt /usr/bin/apt1
mv /User /User1
mv /usr/bin/apt-cache /usr/bin/apt-cache1
mv /usr/bin/apt-cdrom /usr/bin/apt-cdrom1
mv /usr/bin/apt-config /usr/bin/apt-config1
mv /usr/bin/apt-get /usr/bin/apt-get1
mv /usr/bin/apt-key /usr/bin/apt-key1
mv /usr/bin/apt-mark /usr/bin/apt-mark1
mv /var/lib/cydia /var/lib/cydia1
rm -rf  /var/cache/apt
rm -rf  /var/lib/apt
rm -rf  /var/log/apt
